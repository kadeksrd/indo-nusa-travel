import { createClient } from "@/lib/supabase/server";
import UpdateStatusButton from "./UpdateStatusButton";
import { format } from "date-fns";
import { id } from "date-fns/locale";

const statusColor: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  dikonfirmasi: "bg-blue-100 text-blue-700",
  selesai: "bg-green-100 text-green-700",
  dibatalkan: "bg-red-100 text-red-700",
};

export default async function AdminPemesananPage() {
  const supabase = createClient();
  const { data: pemesanans } = await supabase
    .from("pemesanan")
    .select("*, paket_wisata(nama), rental_mobil(nama)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Pemesanan</h1>

      <div className="bg-white rounded-xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                {[
                  "Kode",
                  "Layanan",
                  "Pemesan",
                  "Tanggal",
                  "Total",
                  "Status",
                  "Aksi",
                ].map((h) => (
                  <th
                    key={h}
                    className="text-left py-3 px-4 text-gray-500 font-medium"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y">
              {(pemesanans || []).map((p: any) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-mono text-xs">
                    {p.kode_pemesanan}
                  </td>
                  <td className="py-3 px-4 max-w-xs truncate">
                    {p.paket_wisata?.nama || p.rental_mobil?.nama}
                  </td>
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium">{p.nama_lengkap}</p>
                      <p className="text-gray-400 text-xs">{p.nomor_hp}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-500">
                    {format(new Date(p.tanggal_berangkat), "dd MMM yyyy", {
                      locale: id,
                    })}
                  </td>
                  <td className="py-3 px-4 font-medium">
                    Rp {p.total_harga?.toLocaleString("id-ID")}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-xs px-2 py-1 rounded-full font-medium ${statusColor[p.status]}`}
                    >
                      {p.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <UpdateStatusButton id={p.id} currentStatus={p.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
